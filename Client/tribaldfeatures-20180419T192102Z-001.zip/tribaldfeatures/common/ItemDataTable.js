import React from 'react'

const ItemDataTable = ({}) => {
    return ();
}

export default ItemDataTable;